addappid(766370)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(766371,0,"fa01c87764bb04a9345b076ed1379153be827db70ab7431eb23c05990c9c16d2")
setManifestid(766371,"8764458200843126929")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]