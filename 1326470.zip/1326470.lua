addappid(1326470)
addappid(1326471, 1, "dcc8b76a7563c836c1aed54a46abf85e7fec5fccabc0dd8e176d2151173e508e")
setManifestid(1326471, "388336038807447507", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]