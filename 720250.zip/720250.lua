addappid(720250)
addappid(720251,0,"4575e37a7087a13c47b386424bd698373128854437da3e13a133b6cdf247323e")
setManifestid(720251,"6943644079456336185")
addappid(720252,0,"a86283e8bc7ba5039aaa31290e78226f9650732e90d65e234217c1c332d96760")
setManifestid(720252,"5951049502433706761")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]