addappid(414700)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(414701,0,"cacb82c7172211af76cdfefc4cb22d88140cfecd92c21c02bc3692aebf7402a3")
setManifestid(414701,"4849578644945068180")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]