addappid(739630)
setManifestid(228988,"6645201662696499616")
addappid(739631,0,"a0af61717bae449e5db4a1cc6eb68d7604ac3a8e05ff5226faa14b5be67d640c")
setManifestid(739631,"5175881086456704659")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]