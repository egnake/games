addappid(242760)
addappid(242761,0,"786dfb9db41be351c888b4a930d5295dfe6c8c4bbc4e442f0e1ced301c4d24df")
setManifestid(242761,"5529756524060062456")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]