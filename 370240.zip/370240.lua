addappid(370240)
addappid(228984)
setManifestid(228984,"2547553897526095397")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(370241,0,"2834e0599f82797bd1af42488a12abeb892bd2d3e9a8ce684fd601e6e56c1cab")
setManifestid(370241,"476087243588707670")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]